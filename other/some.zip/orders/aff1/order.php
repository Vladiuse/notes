<?php 
// ***** ПП Aff1 *****
if (isset($_COOKIE["NAHUI"])) {
    setcookie("NAHUI-2", "123",time() + (3600 * 24));
	}
if (isset($_COOKIE["NAHUI-2"])) {
    header('Location: http://google.com/');
    return;
    }/
if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) { $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP']; }
$ip = $_SERVER['REMOTE_ADDR'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$apiKey = 'Hq4xOz20LdQgsmmr';
$sub1 = $_POST['sub1'];
$sub2 = $_POST['bay'];
// Flow data
$country = 'NG';
$offer_id = 'gwp4nXwa';
$stream_hid = 'kElJsJaN';
$city = $_POST['city'];
$fbp = $_POST['fbp'];
$params=array(
    'api_key' => $apiKey,
    'ip' => $ip,
    'country_code' => $country,
    'city' => $city,
    'phone' => $phone,
    'name' => $name,
    'target_hash' => $offer_id,
    'flow_hash' => $stream_hid,
    'clickid' => $sub1,
    'sub2' => $sub2,

);

$time = date('Y-m-d H:i:s');
$message = "$time;$fbp;$sub1;$sub2;$ip;$name;$phone;$city;\n";
// WRITE_LOG
file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX); 

$url = "https://api.aff1.com/v3/lead.create";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
$return = curl_exec($ch);

// WRITE_LOG
file_put_contents('log.txt', $return . "\n", FILE_APPEND | LOCK_EX); 
curl_close($ch);
setcookie("NAHUI", "123",time() + (3600 * 24));
date_default_timezone_set('Europe/Moscow');

header("Location: success.php?fbp=".$fbp);
exit;

?>

