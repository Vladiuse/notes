<?php

$order = array (
	'campaign_id' => 'xxxxx',
	'name' => $_POST['name'],
	'phone' => $_POST['phone'],
	'sid5' => $_POST['sub1'],
	'sid2' => $_POST['bay'],
);

// Define ip
if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
	$ip =  $_SERVER['HTTP_CF_CONNECTING_IP'];
}  elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
	$ip =  $_SERVER['HTTP_X_REAL_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip =  $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip =  $_SERVER['REMOTE_ADDR'];
}

$order['ip'] = $ip;
$fbp = (isset($_POST['fbp']) && !empty($_POST['fbp'])) ? $_POST['fbp'] : $_POST['fbp'];
$parsed_referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_QUERY);
parse_str($parsed_referer, $referer_query);

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://tracker.everad.com/conversion/new" );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($ch, CURLOPT_POST,           1 );
curl_setopt($ch, CURLOPT_POSTFIELDS,     http_build_query(array_merge($referer_query, $order)) );
curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: application/x-www-form-urlencoded'));

$result=curl_exec ($ch);
// ЗАПИСЬ В LOG.TXT
$today = date("m.d.y H:i:s");
$message = $_POST['name'] . ";" . $_POST['phone'] . ";" . $today . ";" . $_POST['sub1'] . ";" . $_POST['bay'] . ";" . $ip . ";" . $result . ";" . $fbp . "\n";
// $message = "$_POST['name'];$_POST['phone'];$today;$_POST['sub1'];$_POST['bay'];$ip;$result;$fbp\n";

file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX);

if ($result === 0) {
	echo "Timeout! Everad CPA 2 API didn't respond within default period!";
} else {
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	if ($httpCode === 200) {
		echo "Good! Order accepted!";
        header('Location: success/success.php', true, 302);
	} else if ($httpCode === 400) {
		echo "Order data is invalid! Order is not accepted!";
	} else {
		echo "Unknown error happened! Order is not accepted! Check campaign_id, probably no landing exists for your campaign!";
	}
}

?>