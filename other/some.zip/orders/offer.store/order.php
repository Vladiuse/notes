
<?php
// if (isset($_COOKIE["NAHUI"])) {
//     setcookie("NAHUI-2", "123",time() + (3600 * 24));
// 	}
// if (isset($_COOKIE["NAHUI-2"])) {
//     header('Location: http://google.com/');
//     return;
//     }
if (empty( $_POST )) die("Bad request");
$data = $_POST;
$data["offer"] = 2;
$data["flow"] = 556;
// $data["base"] = "0";
// $data["currency"] = "EUR";
// $data["country"] = '';
$name = $_POST['name'];
$phone = $_POST['phone'];
$sub1 = $_POST["sub1"];
$bay = $_POST["bay"];
$data["sub1"] = $sub1;
$data["bay"] = $bay;
$data["ip"] = $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( $_SERVER["HTTP_X_FORWARDED_FOR"] ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"] );
$data["ua"] = $_SERVER["HTTP_USER_AGENT"];
if (isset( $data["phonecc"] )) $data["phone"] = $data["phonecc"].$data["phone"];
$data = http_build_query( $data );
$curl = curl_init( "https://offer.store/api/wm/push.json?id=266-35400ed97ffe1c51453adb95f836e0aa" );
curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $curl, CURLOPT_TIMEOUT, 30 );
curl_setopt( $curl, CURLOPT_POST, 1 );
curl_setopt( $curl, CURLOPT_POSTFIELDS, $data );
$fbp = (isset($_POST['fbp']) && !empty($_POST['fbp'])) ? $_POST['fbp'] : $_POST['fbp'];
$result = json_decode( curl_exec( $curl ), true );
curl_close( $curl );
$today = date("m.d.y H:i:s");
$my_ip = $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( $_SERVER["HTTP_X_FORWARDED_FOR"] ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"] );
$message = "$today;$name;$phone;$my_ip;$sub1;$bay;$fbp;$result\n";
file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX); 
setcookie("NAHUI", "123",time() + (3600 * 24));
if ( $result["url"] ) {
	header( "Location: " . $result["url"] );
} else header( "Location: success/success.php?fbp=$fbp" . http_build_query($result) );


# ---------------- 
die();
?>