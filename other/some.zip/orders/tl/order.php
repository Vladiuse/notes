<?php 
if (isset($_COOKIE["NAHUI"])) {
    setcookie("NAHUI-2", "123",time() + (3600 * 24));
	}
if (isset($_COOKIE["NAHUI-2"])) {
    header('Location: http://google.com/');
    return;
    }
if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) { $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP']; }
$ip = $_SERVER['REMOTE_ADDR'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$apiKey = 'lUuBV6Rt2I9b3ueAb3V11rVQdc8JFUzcLLjtCGZWcLL9KPofq3b9OVvwp9iah';
$sub1 = (isset($_POST['sub1']) && !empty($_POST['sub1'])) ? $_POST['sub1'] : $_POST['sub1'];
$sub2 = $_POST['bay'];
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';
// Flow data
$country = 'XX';
$offer_id = 'XXXXX';
$stream_hid = 'XXXXXX';

$fbp = (isset($_GET['_fbp']) && !empty($_GET['_fbp'])) ? $_GET['_fbp'] : $_POST['fbp'];

if (isset($phone)) {
 

$params=array(
    'key' => $apiKey,
    'ip_address' => $ip,
	'country' => $country,
	'phone' => $phone,
    'name' => $name,
    'offer_id' => $offer_id,
    'stream_hid' => $stream_hid,
    'sub1' => $sub1,
    'sub2' => $sub2,

);
$url = "http://api.cpa.tl/api/lead/send";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
$return = curl_exec($ch);
curl_close($ch);
setcookie("NAHUI", "123",time() + (3600 * 24));

date_default_timezone_set('Europe/Moscow');
$time = date('Y-m-d H:i:s');
$message = "$time;$fbp;$sub1;$sub2;$ip;$name;$phone;$add;$return\n";
file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX); 

header("Location: success/success.php?fbp=$fbp&name=$name&phone=$phone");



exit;

} else {
   date_default_timezone_set('Europe/Moscow');
    $time = date('Y-m-d H:i:s');
    $message = "$time;$sub1;$sub1;$ip;$fio;$phone\n";
    file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX);
}

?>

