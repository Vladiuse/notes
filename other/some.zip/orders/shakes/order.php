<?php
// Shakes
if (isset($_COOKIE["NAHUI"])) {
    setcookie("NAHUI-2", "123",time() + (3600 * 24));
	}
if (isset($_COOKIE["NAHUI-2"])) {
    header('Location: http://google.com/');
    return;
    }
/**
 * Базовая конфигурация
 */
// * Апи ключ вашего акканута
$apiKey = 'cbbc5b3ee5fb50ade82965ac5924e6e7';
// * Домен проекта на который происходит отправка заказов
$domain = 'shakes.pro';
// Урл оригинального лендинга, необходим для корректого расчета Вашей статистики
$landingUrl = 'http://XXXXXXX';
// * Идентификатор оффера на который вы льете
$offerId = 'XXXX';
// Код потока заведенного в системе, если указан, статистика будет записываться на данный поток
$streamCode = 'XXXX';
$country = 'XX';
// Страница, отдаваемая при успешном заказе
$successPage = 'success/success.php';
// Страница, отдаваемая в случае ошибки
$errorPage = 'index.html';
/**
 * Формирование отправляемого заказа
 */
$fbp = (isset($_POST['fbp']) && !empty($_POST['fbp'])) ? $_POST['fbp'] : $_POST['fbp'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$bay = $_POST['bay'];
$sub1 = $_POST['sub1'];
$ip = $_SERVER["HTTP_CF_CONNECTING_IP"] ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( $_SERVER["HTTP_X_FORWARDED_FOR"] ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"] );

$params = [
    #'countryCode' => (!empty($_POST['country']) ? $_POST['country'] : ($_GET['country'] ? $_GET['country'] : 'RU')),
    'countryCode' => $country,
    'createdAt' => date('Y-m-d H:i:s'),
    'ip' => (!empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null), // ip пользователя
    'landingUrl' => $landingUrl,
    'name' => (!empty($_POST['name']) ? $_POST['name'] : ($_GET['name'] ? $_GET['name'] : '')),
    'offerId' => $offerId,
    'phone' => (!empty($_POST['phone']) ? $_POST['phone'] : ($_GET['phone'] ? $_GET['phone'] : '')),
    'referrer' => (!empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null),
    'streamCode' => $streamCode,
    'sub1' => (!empty($_POST['sub1']) ? $_POST['sub1'] : ''),
    'sub2' => (!empty($_POST['bay']) ? $_POST['bay'] : ''),
    'sub3' => (!empty($_GET['sub3']) ? $_GET['sub3'] : ''),
    'sub4' => (!empty($_GET['sub4']) ? $_GET['sub4'] : ''),
    'userAgent' => (!empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '-'),
];

$time = date('Y-m-d H:i:s');
$message = "$time;$fbp;$bay;$sub1;$ip;$name;$phone;\n";
// WRITE_LOG USER_DATA
file_put_contents('log.txt', $message, FILE_APPEND | LOCK_EX); 


$url = "http://$domain?r=/api/order/in&key=$apiKey";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_REFERER, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
$return = curl_exec($ch);

// WRITE_LOG PP ANSWER
file_put_contents('log.txt', $return."\n", FILE_APPEND | LOCK_EX); 
setcookie("NAHUI", "123",time() + (3600 * 24));
header("Location: success/success.php?fbp=$fbp&name=$name&phone=$phone");
exit;
?>

